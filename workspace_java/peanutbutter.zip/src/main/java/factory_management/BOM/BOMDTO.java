package factory_management.BOM;

public class BOMDTO {
	 private String productcode;	
	 private String productname;
	public String getProductname() {
		return productname;
	}
	public String getProductcode() {
		return productcode;
	}
	public void setProductcode(String productcode) {
		this.productcode = productcode;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}	
}
